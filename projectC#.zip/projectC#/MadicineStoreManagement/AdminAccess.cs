﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class AdminAccess : Form
    {
        public AdminAccess()
        {
            InitializeComponent();
        }

        private void buttonCusInfo_Click(object sender, EventArgs e)
        {
            Form1 open = new Form1();
            open.Show();
           // Visible = false;
            this.Hide();
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            Login open = new Login();
            open.Show();
           // Visible = false;
            this.Hide();
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonMediInfo_Click(object sender, EventArgs e)
        {
            Medicine open = new Medicine();
            open.Show();
            // Visible = false;
            this.Hide();
        }

       
    }
}
