﻿namespace MadicineStoreManagement
{
    partial class Sell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCross = new System.Windows.Forms.Button();
            this.comboBoxSell = new System.Windows.Forms.ComboBox();
            this.labelSell = new System.Windows.Forms.Label();
            this.buttonMediExit = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.labelAmount = new System.Windows.Forms.Label();
            this.labelsellMediName = new System.Windows.Forms.Label();
            this.textBoxAmount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonCross
            // 
            this.buttonCross.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCross.Location = new System.Drawing.Point(627, 12);
            this.buttonCross.Name = "buttonCross";
            this.buttonCross.Size = new System.Drawing.Size(29, 27);
            this.buttonCross.TabIndex = 8;
            this.buttonCross.Text = "X";
            this.buttonCross.UseVisualStyleBackColor = true;
            this.buttonCross.Click += new System.EventHandler(this.buttonCross_Click);
            // 
            // comboBoxSell
            // 
            this.comboBoxSell.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBoxSell.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxSell.FormattingEnabled = true;
            this.comboBoxSell.Location = new System.Drawing.Point(183, 105);
            this.comboBoxSell.Name = "comboBoxSell";
            this.comboBoxSell.Size = new System.Drawing.Size(121, 21);
            this.comboBoxSell.TabIndex = 13;
            this.comboBoxSell.SelectedIndexChanged += new System.EventHandler(this.comboBoxSell_SelectedIndexChanged);
            // 
            // labelSell
            // 
            this.labelSell.AutoSize = true;
            this.labelSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSell.ForeColor = System.Drawing.Color.White;
            this.labelSell.Location = new System.Drawing.Point(235, 32);
            this.labelSell.Name = "labelSell";
            this.labelSell.Size = new System.Drawing.Size(163, 24);
            this.labelSell.TabIndex = 14;
            this.labelSell.Text = "SELL MEDICINE";
            // 
            // buttonMediExit
            // 
            this.buttonMediExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediExit.Location = new System.Drawing.Point(183, 195);
            this.buttonMediExit.Name = "buttonMediExit";
            this.buttonMediExit.Size = new System.Drawing.Size(136, 23);
            this.buttonMediExit.TabIndex = 18;
            this.buttonMediExit.Text = "&Exit";
            this.buttonMediExit.UseVisualStyleBackColor = true;
            this.buttonMediExit.Click += new System.EventHandler(this.buttonMediExit_Click);
            // 
            // buttonOk
            // 
            this.buttonOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOk.Location = new System.Drawing.Point(336, 195);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(136, 23);
            this.buttonOk.TabIndex = 19;
            this.buttonOk.Text = "&OK";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmount.ForeColor = System.Drawing.Color.White;
            this.labelAmount.Location = new System.Drawing.Point(321, 106);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(65, 15);
            this.labelAmount.TabIndex = 20;
            this.labelAmount.Text = "AMOUNT";
            // 
            // labelsellMediName
            // 
            this.labelsellMediName.AutoSize = true;
            this.labelsellMediName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsellMediName.ForeColor = System.Drawing.Color.White;
            this.labelsellMediName.Location = new System.Drawing.Point(73, 106);
            this.labelsellMediName.Name = "labelsellMediName";
            this.labelsellMediName.Size = new System.Drawing.Size(89, 15);
            this.labelsellMediName.TabIndex = 21;
            this.labelsellMediName.Text = "NAME_MEDI";
            // 
            // textBoxAmount
            // 
            this.textBoxAmount.Location = new System.Drawing.Point(414, 105);
            this.textBoxAmount.Name = "textBoxAmount";
            this.textBoxAmount.Size = new System.Drawing.Size(139, 20);
            this.textBoxAmount.TabIndex = 22;
            // 
            // Sell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(677, 306);
            this.Controls.Add(this.textBoxAmount);
            this.Controls.Add(this.labelsellMediName);
            this.Controls.Add(this.labelAmount);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonMediExit);
            this.Controls.Add(this.labelSell);
            this.Controls.Add(this.comboBoxSell);
            this.Controls.Add(this.buttonCross);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sell";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sell";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCross;
        private System.Windows.Forms.ComboBox comboBoxSell;
        private System.Windows.Forms.Label labelSell;
        private System.Windows.Forms.Button buttonMediExit;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelsellMediName;
        private System.Windows.Forms.TextBox textBoxAmount;
    }
}