﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class Medicine : Form
    {
        CustomerDBDataContext dx = new CustomerDBDataContext();
        Medicine_Table medi = new Medicine_Table();
        public Medicine()
        {
            InitializeComponent();
        }

        private void labelAmount_Click(object sender, EventArgs e)
        {

        }

        private void Medicine_Load(object sender, EventArgs e)
        {

        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonMediExit_Click(object sender, EventArgs e)
        {
            AdminAccess open = new AdminAccess();
            open.Show();
            // Visible = false;
            this.Hide();
        }

        private void buttonmediInsert_Click(object sender, EventArgs e)
        {
         

             if (textBoxMediName.Text == "" || textBoxMediPrice.Text == "" || textBoxSelf.Text == "" || textBoxAmount .Text== ""||textBoxmediId.Text!="")
             {
                 MessageBox.Show("TRY AGAIN !!! ");
                 textBoxmediId.Text = null;
                 textBoxMediName.Text = null;
                 textBoxMediPrice.Text = null;
                 textBoxSelf.Text = null;
                 textBoxAmount.Text = null;
             }
             else
             {

                 int price = Convert.ToInt32(textBoxMediPrice.Text);
                 int self = Convert.ToInt32(textBoxSelf.Text);
                 int amount = Convert.ToInt32(textBoxAmount.Text);
                 medi.Medi_Name = textBoxMediName.Text;
                 medi.Medi_Amount = amount;
                 medi.Medi_Price = price;
                 medi.Medi_Self = self;
                 CustomerDBDataContext dxt = new CustomerDBDataContext();
                 dx.Medicine_Tables.InsertOnSubmit(medi);
                 dx.SubmitChanges();
                 MessageBox.Show("SAVE SUCCESSFULLY ");
                 textBoxmediId.Text = null;
                 textBoxMediName.Text = null;
                 textBoxMediPrice.Text = null;
                 textBoxSelf.Text = null;
                 textBoxAmount.Text = null;
             }
         

        }

        private void buttonMediUpdate_Click(object sender, EventArgs e)
        {

            if (textBoxMediName.Text == "" || textBoxMediPrice.Text == "" || textBoxSelf.Text == "" || textBoxAmount.Text == "" || textBoxmediId.Text == "")
            {
                MessageBox.Show("TRY AGAIN !!! ");
                textBoxmediId.Text = null;
                textBoxmediId.Text = null;
                textBoxMediName.Text = null;
                textBoxMediPrice.Text = null;
                textBoxSelf.Text = null;
                textBoxAmount.Text = null;
            }
            else
            {

                int id = int.Parse(textBoxmediId.Text);
                Medicine_Table medi = dx.Medicine_Tables.SingleOrDefault(x => x.Medi_Id == id);
                int price = Convert.ToInt32(textBoxMediPrice.Text);
                int self = Convert.ToInt32(textBoxSelf.Text);
                int amount = Convert.ToInt32(textBoxAmount.Text);

                if (medi != null)
                {
                    medi.Medi_Name = textBoxMediName.Text;
                    medi.Medi_Price = price;
                    medi.Medi_Self = self;
                    medi.Medi_Amount = amount;
                    MessageBox.Show("EDITED SUCCESSFULLY ");
                    dx.SubmitChanges();
                    textBoxmediId.Text = null;
                    textBoxMediName.Text = null;
                    textBoxMediPrice.Text = null;
                    textBoxSelf.Text = null;
                    textBoxAmount.Text = null;
                }
                else
                {
                    MessageBox.Show("TRY AGAIN !!! ");
                    textBoxmediId.Text = null;
                    textBoxmediId.Text = null;
                    textBoxMediName.Text = null;
                    textBoxMediPrice.Text = null;
                    textBoxSelf.Text = null;
                    textBoxAmount.Text = null;
                }
            }
        }

        private void buttonMediDelete_Click(object sender, EventArgs e)
        {
            if (textBoxmediId.Text == "" || textBoxMediName.Text != "" || textBoxMediPrice.Text != "" || textBoxSelf.Text != "" || textBoxAmount.Text != "")
            { MessageBox.Show("TRY AGAIN");
            textBoxmediId.Text = null;
            textBoxmediId.Text = null;
            textBoxMediName.Text = null;
            textBoxMediPrice.Text = null;
            textBoxSelf.Text = null;
            textBoxAmount.Text = null;
             }
            else
            {
                int id = Convert.ToInt32(textBoxmediId.Text);
                Medicine_Table s = dx.Medicine_Tables.SingleOrDefault(x => x.Medi_Id == id);
                if (s != null && textBoxMediName.Text == "" && textBoxMediPrice.Text == "" && textBoxAmount.Text == "" && textBoxSelf.Text == "")
                {
                    
                    MessageBox.Show("Delete successfully");
                    dx.Medicine_Tables.DeleteOnSubmit(s);
                    dx.SubmitChanges();
                    textBoxmediId.Text = null;
                    textBoxMediName.Text = null;
                    textBoxMediPrice.Text = null;
                    textBoxSelf.Text = null;
                    textBoxAmount.Text = null;
                    
                }
                else { MessageBox.Show("TRY AGAIN");
                textBoxmediId.Text = null;
                textBoxMediName.Text = null;
                textBoxMediPrice.Text = null;
                textBoxSelf.Text = null;
                textBoxAmount.Text = null;
                }
            }
           
        }

        private void buttonmediView_Click(object sender, EventArgs e)
        {
              CustomerDBDataContext dxt = new CustomerDBDataContext();
            var getData = (
            from x in dxt.GetTable<Medicine_Table>()
            select x

            );

            medicineAdmindataGridView1.DataSource = getData;
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            
            string search = textBoxSearch.Text;
            var sresult = from p in dx.Medicine_Tables
                          where p.Medi_Name.StartsWith(search) ||p.Medi_Name.EndsWith(search)||p.Medi_Id.ToString().StartsWith(search)
                          select p;
            medicineAdmindataGridView1.DataSource = sresult;
        }

        private void medicineAdmindataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
