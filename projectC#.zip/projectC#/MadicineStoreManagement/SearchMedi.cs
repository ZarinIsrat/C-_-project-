﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class SearchMedi : Form
    {
        CustomerDBDataContext dx = new CustomerDBDataContext();
        public SearchMedi()
        {
            InitializeComponent();
        }

        private void buttonMediExit_Click(object sender, EventArgs e)
        {

            User open = new User();
            open.Show();
            // Visible = false;
            this.Hide();
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBoxMediPrice_TextChanged(object sender, EventArgs e)
        {
            string search = textBoxMediPrice.Text;
            var sresult = from p in dx.Medicine_Tables
                          where p.Medi_Name.StartsWith(search) || p.Medi_Name.EndsWith(search) || p.Medi_Id.ToString().StartsWith(search)
                          select p;
            medicineAdmindataGridView1.DataSource = sresult;
        }
    }
}
