﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
        }

        private void buttonUser_Click(object sender, EventArgs e)
        {
            User open = new User();
            open.Show();
            // Visible = false;
            this.Hide();

        }

        private void buttonADMIN_Click(object sender, EventArgs e)
        {
            Login open = new Login();
            open.Show();
           // Visible = false;
            this.Hide();
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
