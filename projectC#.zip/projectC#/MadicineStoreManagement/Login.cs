﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class Login : Form
    {
        Admin_Table admin = new Admin_Table();
        CustomerDBDataContext dx = new CustomerDBDataContext();

        public Login()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            string userName = textBoxUsername.Text;
            string passWord = textBoxPass.Text;
            if (string.IsNullOrEmpty(userName))
            {
               
                MessageBox.Show(" Please enter you username and password properly","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                textBoxUsername.Focus();
                return;
              }
                try
                {
                    using ( CustomerDBDataContext dx = new CustomerDBDataContext()) {var q =from o in dx.Admin_Tables where   o.User_name==textBoxUsername.Text&&o.Password==textBoxPass.Text select o;

                    if (q.SingleOrDefault() != null) { MessageBox.Show("YOU ARE SUCCESSFULLY LOGIN");
                                                       textBoxPass.Text = null;
                                                      textBoxUsername.Text = null;
                                                      AdminAccess open = new AdminAccess();
                                                      open.Show();
                                                      // Visible = false;
                                                      this.Hide();
                    }
                    else { MessageBox.Show("INCORRECT USERNAME OR PASSWORD ");
                    textBoxPass.Text = null;
                    textBoxUsername.Text = null;
                    }
                    }                                                        
                                                         
                }
                catch (Exception Exception){
                    MessageBox.Show(Exception.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);}
                
              }
        

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBoxUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                textBoxPass.Focus();

        }

        private void Login_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == (char)13)
                buttonOK.PerformClick();
        }

        private void buttonCancle_Click(object sender, EventArgs e)
        {
            Start open = new Start ();
            open.Show();
            // Visible = false;
            this.Hide();
        }
    }
}
