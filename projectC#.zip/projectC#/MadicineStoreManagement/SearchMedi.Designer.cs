﻿namespace MadicineStoreManagement
{
    partial class SearchMedi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxMediPrice = new System.Windows.Forms.TextBox();
            this.medicineAdmindataGridView1 = new System.Windows.Forms.DataGridView();
            this.labelUser = new System.Windows.Forms.Label();
            this.buttonCross = new System.Windows.Forms.Button();
            this.buttonMediExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.medicineAdmindataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxMediPrice
            // 
            this.textBoxMediPrice.Location = new System.Drawing.Point(222, 77);
            this.textBoxMediPrice.Name = "textBoxMediPrice";
            this.textBoxMediPrice.Size = new System.Drawing.Size(333, 20);
            this.textBoxMediPrice.TabIndex = 4;
            this.textBoxMediPrice.TextChanged += new System.EventHandler(this.textBoxMediPrice_TextChanged);
            // 
            // medicineAdmindataGridView1
            // 
            this.medicineAdmindataGridView1.AllowUserToAddRows = false;
            this.medicineAdmindataGridView1.AllowUserToDeleteRows = false;
            this.medicineAdmindataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.medicineAdmindataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.medicineAdmindataGridView1.Location = new System.Drawing.Point(27, 123);
            this.medicineAdmindataGridView1.Name = "medicineAdmindataGridView1";
            this.medicineAdmindataGridView1.ReadOnly = true;
            this.medicineAdmindataGridView1.Size = new System.Drawing.Size(662, 159);
            this.medicineAdmindataGridView1.TabIndex = 11;
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUser.ForeColor = System.Drawing.Color.White;
            this.labelUser.Location = new System.Drawing.Point(271, 21);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(204, 24);
            this.labelUser.TabIndex = 12;
            this.labelUser.Text = "SEARCH MEDICINE ";
            // 
            // buttonCross
            // 
            this.buttonCross.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCross.Location = new System.Drawing.Point(684, 12);
            this.buttonCross.Name = "buttonCross";
            this.buttonCross.Size = new System.Drawing.Size(29, 24);
            this.buttonCross.TabIndex = 16;
            this.buttonCross.Text = "X";
            this.buttonCross.UseVisualStyleBackColor = true;
            this.buttonCross.Click += new System.EventHandler(this.buttonCross_Click);
            // 
            // buttonMediExit
            // 
            this.buttonMediExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediExit.Location = new System.Drawing.Point(285, 316);
            this.buttonMediExit.Name = "buttonMediExit";
            this.buttonMediExit.Size = new System.Drawing.Size(136, 23);
            this.buttonMediExit.TabIndex = 17;
            this.buttonMediExit.Text = "&Exit";
            this.buttonMediExit.UseVisualStyleBackColor = true;
            this.buttonMediExit.Click += new System.EventHandler(this.buttonMediExit_Click);
            // 
            // SearchMedi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(736, 369);
            this.Controls.Add(this.buttonMediExit);
            this.Controls.Add(this.buttonCross);
            this.Controls.Add(this.labelUser);
            this.Controls.Add(this.medicineAdmindataGridView1);
            this.Controls.Add(this.textBoxMediPrice);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchMedi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchMedi";
            ((System.ComponentModel.ISupportInitialize)(this.medicineAdmindataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxMediPrice;
        private System.Windows.Forms.DataGridView medicineAdmindataGridView1;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.Button buttonCross;
        private System.Windows.Forms.Button buttonMediExit;
    }
}