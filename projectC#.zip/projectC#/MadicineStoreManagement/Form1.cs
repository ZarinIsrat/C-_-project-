﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MadicineStoreManagement
{
    public partial class Form1 : Form
    {
        Customer_Table cus = new Customer_Table();
        CustomerDBDataContext dx = new CustomerDBDataContext();


        public Form1()
        {
            InitializeComponent();
        }

       

        private void buttonSave_Click(object sender, EventArgs e)
        {
         
            if (textBoxName.Text == "" || textBoxAddress.Text == "" || textBoxCity.Text == "" || textBoxMobile.Text == ""||textBoxId.Text!="")
            {
                MessageBox.Show(" TRY AGAIN");
                textBoxId.Text = null;
                textBoxName.Text = null;
                textBoxAddress.Text = null;
                textBoxCity.Text = null;
                textBoxMobile.Text = null;

            }
            else
            {
                cus.Cus_name = textBoxName.Text;
                cus.Cus_address = textBoxAddress.Text;
                cus.Cus_city = textBoxCity.Text;
                cus.Cus_mobile = textBoxMobile.Text;
                CustomerDBDataContext dxt = new CustomerDBDataContext();
                dx.Customer_Tables.InsertOnSubmit(cus);
                dx.SubmitChanges();
                MessageBox.Show("SAVE SUCCESSFULLY ");
                textBoxId.Text = null;
                textBoxName.Text = null;
                textBoxAddress.Text = null;
                textBoxCity.Text = null;
                textBoxMobile.Text = null;
            }
          
           
        }

       

        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }
       

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if ((textBoxName.Text == "" || textBoxAddress.Text == "" || textBoxCity.Text == "" || textBoxMobile.Text == "" || textBoxId.Text == ""))
            {
                MessageBox.Show(" TRY AGAIN");
                textBoxId.Text = null;
                textBoxName.Text = null;
                textBoxAddress.Text = null;
                textBoxCity.Text = null;
                textBoxMobile.Text = null;

            }
            else
            {

                int id = int.Parse(textBoxId.Text);
                Customer_Table cus = dx.Customer_Tables.SingleOrDefault(x => x.Id == id);

                if (cus != null)
                {

                    MessageBox.Show("Edited  SUCCESSFULLY ");
                    cus.Cus_name = textBoxName.Text;
                    cus.Cus_address = textBoxAddress.Text;
                    cus.Cus_mobile = textBoxMobile.Text;
                    cus.Cus_city = textBoxCity.Text;
                    dx.SubmitChanges();
                    textBoxId.Text = null;
                    textBoxName.Text = null;
                    textBoxAddress.Text = null;
                    textBoxCity.Text = null;
                    textBoxMobile.Text = null;

                }
                else { MessageBox.Show("NOT found ");
                textBoxId.Text = null;
                textBoxName.Text = null;
                textBoxAddress.Text = null;
                textBoxCity.Text = null;
                textBoxMobile.Text = null;
                }
            }
                 
                
            
            
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (textBoxId.Text == "" || textBoxName.Text != "" || textBoxAddress.Text != "" || textBoxCity.Text != "" || textBoxMobile.Text != "")
            {
                MessageBox.Show(" TRY AGAIN PUT YOUR ID PROPERLY ");
                textBoxId.Text = null;
                textBoxName.Text = null;
                textBoxAddress.Text = null;
                textBoxCity.Text = null;
                textBoxMobile.Text = null;
            }


            else
            {

                int id = int.Parse(textBoxId.Text);

                Customer_Table cust = dx.Customer_Tables.SingleOrDefault(x => x.Id == id);
                if (cust != null)
                {

                    dx.Customer_Tables.DeleteOnSubmit(cust);
                    dx.SubmitChanges();
                    MessageBox.Show("Delete  SUCCESSFULLY ");
                    textBoxId.Text = null;
                    textBoxName.Text = null;
                    textBoxAddress.Text = null;
                    textBoxCity.Text = null;
                    textBoxMobile.Text = null;
                }
                else {
                    MessageBox.Show(" TRY AGAIN PUT YOUR ID PROPERLY ");
                    textBoxId.Text = null;
                    textBoxName.Text = null;
                    textBoxAddress.Text = null;
                    textBoxCity.Text = null;
                    textBoxMobile.Text = null;
      
                }
            }
            

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            AdminAccess open = new AdminAccess();
            open.Show();
            Visible = false;
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            //view();
        }
       
        private void dgcustomer_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

     
        private void buttonview_Click_1(object sender, EventArgs e)
        {
            CustomerDBDataContext dxt = new CustomerDBDataContext();
            var getData = (
            from x in dxt.GetTable<Customer_Table>()
            select x

            );

            customerdataGridView1.DataSource = getData;

        }


       
    }
}
