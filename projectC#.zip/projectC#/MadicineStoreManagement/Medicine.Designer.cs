﻿namespace MadicineStoreManagement
{
    partial class Medicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.labelSelf = new System.Windows.Forms.Label();
            this.textBoxSelf = new System.Windows.Forms.TextBox();
            this.medicineAdmindataGridView1 = new System.Windows.Forms.DataGridView();
            this.labelAmount = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelmediId = new System.Windows.Forms.Label();
            this.textBoxMediName = new System.Windows.Forms.TextBox();
            this.textBoxAmount = new System.Windows.Forms.TextBox();
            this.textBoxMediPrice = new System.Windows.Forms.TextBox();
            this.textBoxmediId = new System.Windows.Forms.TextBox();
            this.labelMedicine = new System.Windows.Forms.Label();
            this.buttonmediInsert = new System.Windows.Forms.Button();
            this.buttonMediUpdate = new System.Windows.Forms.Button();
            this.buttonMediDelete = new System.Windows.Forms.Button();
            this.buttonMediExit = new System.Windows.Forms.Button();
            this.buttonCross = new System.Windows.Forms.Button();
            this.buttonmediView = new System.Windows.Forms.Button();
            this.labelSearch = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.medicineAdmindataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.labelSearch);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.labelSelf);
            this.panel1.Controls.Add(this.textBoxSelf);
            this.panel1.Controls.Add(this.medicineAdmindataGridView1);
            this.panel1.Controls.Add(this.labelAmount);
            this.panel1.Controls.Add(this.labelPrice);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.labelmediId);
            this.panel1.Controls.Add(this.textBoxMediName);
            this.panel1.Controls.Add(this.textBoxAmount);
            this.panel1.Controls.Add(this.textBoxMediPrice);
            this.panel1.Controls.Add(this.textBoxmediId);
            this.panel1.Location = new System.Drawing.Point(1, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(816, 290);
            this.panel1.TabIndex = 0;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(679, 125);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(123, 20);
            this.textBoxSearch.TabIndex = 13;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // labelSelf
            // 
            this.labelSelf.AutoSize = true;
            this.labelSelf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelf.ForeColor = System.Drawing.Color.White;
            this.labelSelf.Location = new System.Drawing.Point(431, 19);
            this.labelSelf.Name = "labelSelf";
            this.labelSelf.Size = new System.Drawing.Size(69, 15);
            this.labelSelf.TabIndex = 12;
            this.labelSelf.Text = "SELF_NO";
            // 
            // textBoxSelf
            // 
            this.textBoxSelf.Location = new System.Drawing.Point(506, 12);
            this.textBoxSelf.Name = "textBoxSelf";
            this.textBoxSelf.Size = new System.Drawing.Size(123, 20);
            this.textBoxSelf.TabIndex = 11;
            // 
            // medicineAdmindataGridView1
            // 
            this.medicineAdmindataGridView1.AllowUserToAddRows = false;
            this.medicineAdmindataGridView1.AllowUserToDeleteRows = false;
            this.medicineAdmindataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.medicineAdmindataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.medicineAdmindataGridView1.Location = new System.Drawing.Point(11, 125);
            this.medicineAdmindataGridView1.Name = "medicineAdmindataGridView1";
            this.medicineAdmindataGridView1.ReadOnly = true;
            this.medicineAdmindataGridView1.Size = new System.Drawing.Size(662, 165);
            this.medicineAdmindataGridView1.TabIndex = 10;
            this.medicineAdmindataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.medicineAdmindataGridView1_CellContentClick);
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmount.ForeColor = System.Drawing.Color.White;
            this.labelAmount.Location = new System.Drawing.Point(228, 62);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(65, 15);
            this.labelAmount.TabIndex = 9;
            this.labelAmount.Text = "AMOUNT";
            this.labelAmount.Click += new System.EventHandler(this.labelAmount_Click);
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrice.ForeColor = System.Drawing.Color.White;
            this.labelPrice.Location = new System.Drawing.Point(228, 12);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(48, 15);
            this.labelPrice.TabIndex = 8;
            this.labelPrice.Text = "PRICE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Medi_Name";
            // 
            // labelmediId
            // 
            this.labelmediId.AutoSize = true;
            this.labelmediId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmediId.ForeColor = System.Drawing.Color.White;
            this.labelmediId.Location = new System.Drawing.Point(11, 17);
            this.labelmediId.Name = "labelmediId";
            this.labelmediId.Size = new System.Drawing.Size(61, 15);
            this.labelmediId.TabIndex = 6;
            this.labelmediId.Text = "Medi_ID";
            // 
            // textBoxMediName
            // 
            this.textBoxMediName.Location = new System.Drawing.Point(100, 61);
            this.textBoxMediName.Name = "textBoxMediName";
            this.textBoxMediName.Size = new System.Drawing.Size(123, 20);
            this.textBoxMediName.TabIndex = 5;
            // 
            // textBoxAmount
            // 
            this.textBoxAmount.Location = new System.Drawing.Point(299, 57);
            this.textBoxAmount.Name = "textBoxAmount";
            this.textBoxAmount.Size = new System.Drawing.Size(123, 20);
            this.textBoxAmount.TabIndex = 4;
            // 
            // textBoxMediPrice
            // 
            this.textBoxMediPrice.Location = new System.Drawing.Point(299, 11);
            this.textBoxMediPrice.Name = "textBoxMediPrice";
            this.textBoxMediPrice.Size = new System.Drawing.Size(123, 20);
            this.textBoxMediPrice.TabIndex = 3;
            // 
            // textBoxmediId
            // 
            this.textBoxmediId.Location = new System.Drawing.Point(100, 16);
            this.textBoxmediId.Name = "textBoxmediId";
            this.textBoxmediId.Size = new System.Drawing.Size(123, 20);
            this.textBoxmediId.TabIndex = 2;
            // 
            // labelMedicine
            // 
            this.labelMedicine.AutoSize = true;
            this.labelMedicine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMedicine.ForeColor = System.Drawing.Color.White;
            this.labelMedicine.Location = new System.Drawing.Point(347, 9);
            this.labelMedicine.Name = "labelMedicine";
            this.labelMedicine.Size = new System.Drawing.Size(114, 24);
            this.labelMedicine.TabIndex = 1;
            this.labelMedicine.Text = "MEDICINE ";
            // 
            // buttonmediInsert
            // 
            this.buttonmediInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonmediInsert.Location = new System.Drawing.Point(222, 357);
            this.buttonmediInsert.Name = "buttonmediInsert";
            this.buttonmediInsert.Size = new System.Drawing.Size(72, 23);
            this.buttonmediInsert.TabIndex = 11;
            this.buttonmediInsert.Text = "&INSERT";
            this.buttonmediInsert.UseVisualStyleBackColor = true;
            this.buttonmediInsert.Click += new System.EventHandler(this.buttonmediInsert_Click);
            // 
            // buttonMediUpdate
            // 
            this.buttonMediUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediUpdate.Location = new System.Drawing.Point(300, 357);
            this.buttonMediUpdate.Name = "buttonMediUpdate";
            this.buttonMediUpdate.Size = new System.Drawing.Size(72, 23);
            this.buttonMediUpdate.TabIndex = 12;
            this.buttonMediUpdate.Text = "&UPDATE";
            this.buttonMediUpdate.UseVisualStyleBackColor = true;
            this.buttonMediUpdate.Click += new System.EventHandler(this.buttonMediUpdate_Click);
            // 
            // buttonMediDelete
            // 
            this.buttonMediDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediDelete.Location = new System.Drawing.Point(378, 357);
            this.buttonMediDelete.Name = "buttonMediDelete";
            this.buttonMediDelete.Size = new System.Drawing.Size(72, 23);
            this.buttonMediDelete.TabIndex = 13;
            this.buttonMediDelete.Text = "&DELETE";
            this.buttonMediDelete.UseVisualStyleBackColor = true;
            this.buttonMediDelete.Click += new System.EventHandler(this.buttonMediDelete_Click);
            // 
            // buttonMediExit
            // 
            this.buttonMediExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediExit.Location = new System.Drawing.Point(456, 357);
            this.buttonMediExit.Name = "buttonMediExit";
            this.buttonMediExit.Size = new System.Drawing.Size(72, 23);
            this.buttonMediExit.TabIndex = 14;
            this.buttonMediExit.Text = "&Exit";
            this.buttonMediExit.UseVisualStyleBackColor = true;
            this.buttonMediExit.Click += new System.EventHandler(this.buttonMediExit_Click);
            // 
            // buttonCross
            // 
            this.buttonCross.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCross.Location = new System.Drawing.Point(774, 9);
            this.buttonCross.Name = "buttonCross";
            this.buttonCross.Size = new System.Drawing.Size(29, 24);
            this.buttonCross.TabIndex = 15;
            this.buttonCross.Text = "X";
            this.buttonCross.UseVisualStyleBackColor = true;
            this.buttonCross.Click += new System.EventHandler(this.buttonCross_Click);
            // 
            // buttonmediView
            // 
            this.buttonmediView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonmediView.Location = new System.Drawing.Point(534, 357);
            this.buttonmediView.Name = "buttonmediView";
            this.buttonmediView.Size = new System.Drawing.Size(72, 23);
            this.buttonmediView.TabIndex = 16;
            this.buttonmediView.Text = "&VIEW";
            this.buttonmediView.UseVisualStyleBackColor = true;
            this.buttonmediView.Click += new System.EventHandler(this.buttonmediView_Click);
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.Color.White;
            this.labelSearch.Location = new System.Drawing.Point(706, 161);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(62, 15);
            this.labelSearch.TabIndex = 14;
            this.labelSearch.Text = "SEARCH";
            // 
            // Medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(819, 392);
            this.Controls.Add(this.buttonmediView);
            this.Controls.Add(this.buttonCross);
            this.Controls.Add(this.buttonMediExit);
            this.Controls.Add(this.buttonMediDelete);
            this.Controls.Add(this.buttonMediUpdate);
            this.Controls.Add(this.buttonmediInsert);
            this.Controls.Add(this.labelMedicine);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Medicine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Medicine";
            this.Load += new System.EventHandler(this.Medicine_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.medicineAdmindataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxMediName;
        private System.Windows.Forms.TextBox textBoxAmount;
        private System.Windows.Forms.TextBox textBoxMediPrice;
        private System.Windows.Forms.TextBox textBoxmediId;
        private System.Windows.Forms.Label labelMedicine;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelmediId;
        private System.Windows.Forms.Label labelSelf;
        private System.Windows.Forms.TextBox textBoxSelf;
        private System.Windows.Forms.DataGridView medicineAdmindataGridView1;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonmediInsert;
        private System.Windows.Forms.Button buttonMediUpdate;
        private System.Windows.Forms.Button buttonMediDelete;
        private System.Windows.Forms.Button buttonMediExit;
        private System.Windows.Forms.Button buttonCross;
        private System.Windows.Forms.Button buttonmediView;
        private System.Windows.Forms.Label labelSearch;
    }
}