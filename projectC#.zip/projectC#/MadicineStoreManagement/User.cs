﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            SearchMedi open = new SearchMedi();
            open.Show();
            // Visible = false;
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Start open = new Start();
            open.Show();
            // Visible = false;
            this.Hide();
        }

        private void buttonSell_Click(object sender, EventArgs e)
        {
            Sell open = new Sell();
            open.Show();
            // Visible = false;
            this.Hide();
        }
    }
}
