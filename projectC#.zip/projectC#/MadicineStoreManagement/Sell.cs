﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadicineStoreManagement
{
    public partial class Sell : Form
    {
        public Sell()
        {
            InitializeComponent();

            CustomerDBDataContext dx = new CustomerDBDataContext();
            string s = comboBoxSell.Text;

            var item = (from d in dx.Medicine_Tables
                        where d.Medi_Name.StartsWith(s)

                        select d);
            comboBoxSell.DataSource = item.ToList();
            comboBoxSell.DisplayMember = "Medi_Name";
            comboBoxSell.ValueMember = "Medi_Id";
            //comboBoxSell.Text = null;

        }

        private void buttonMediExit_Click(object sender, EventArgs e)
        {
            User open = new User();
            open.Show();
            // Visible = false;
            this.Hide();
        }

        private void buttonCross_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBoxSell_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            string name = comboBoxSell.Text;
            CustomerDBDataContext dx = new CustomerDBDataContext();
            Medicine_Table medi = dx.Medicine_Tables.SingleOrDefault(x => x.Medi_Name == name);

           // MessageBox.Show(comboBoxSell.Text);
            //MessageBox.Show(comboBoxSell. SelectedValue.ToString());

            //MessageBox.Show(textBoxAmount.Text);

            int amount;
            bool isAmount = int.TryParse(textBoxAmount.Text, out amount);
            if (!isAmount )
            {
                MessageBox.Show("try again ");
                    comboBoxSell.Text = null;
                    textBoxAmount.Text = null;
            }
            else  if (medi != null)
            {
                if (amount <= medi.Medi_Amount)
                {
                    medi.Medi_Amount = medi.Medi_Amount - amount;
                    dx.SubmitChanges();
                    MessageBox.Show("SELL SUCCESSFULLY ");
                    comboBoxSell.Text = null;
                    textBoxAmount.Text = null;
                }
               
                else
                {

                    MessageBox.Show("AMOUNT OF MEDICINE IS NOT AVAILABLE ");
                    comboBoxSell.Text = null;
                    textBoxAmount.Text = null;
                }
               
            }
           

        }


    }
}
                 
             
             
   
    

