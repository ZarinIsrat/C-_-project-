﻿namespace MadicineStoreManagement
{
    partial class AdminAccess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCusInfo = new System.Windows.Forms.Button();
            this.buttonMediInfo = new System.Windows.Forms.Button();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.labelChoose = new System.Windows.Forms.Label();
            this.buttonCross = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCusInfo
            // 
            this.buttonCusInfo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonCusInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCusInfo.Location = new System.Drawing.Point(71, 114);
            this.buttonCusInfo.Name = "buttonCusInfo";
            this.buttonCusInfo.Size = new System.Drawing.Size(385, 31);
            this.buttonCusInfo.TabIndex = 3;
            this.buttonCusInfo.Text = "&CUSTOMER INFO";
            this.buttonCusInfo.UseVisualStyleBackColor = true;
            this.buttonCusInfo.Click += new System.EventHandler(this.buttonCusInfo_Click);
            // 
            // buttonMediInfo
            // 
            this.buttonMediInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMediInfo.Location = new System.Drawing.Point(71, 168);
            this.buttonMediInfo.Name = "buttonMediInfo";
            this.buttonMediInfo.Size = new System.Drawing.Size(385, 31);
            this.buttonMediInfo.TabIndex = 4;
            this.buttonMediInfo.Text = "&MEDICINE INFO";
            this.buttonMediInfo.UseVisualStyleBackColor = true;
            this.buttonMediInfo.Click += new System.EventHandler(this.buttonMediInfo_Click);
            // 
            // buttonLogout
            // 
            this.buttonLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogout.Location = new System.Drawing.Point(71, 228);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(385, 31);
            this.buttonLogout.TabIndex = 5;
            this.buttonLogout.Text = "&LOGOUT";
            this.buttonLogout.UseVisualStyleBackColor = true;
            this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
            // 
            // labelChoose
            // 
            this.labelChoose.AutoSize = true;
            this.labelChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelChoose.ForeColor = System.Drawing.Color.White;
            this.labelChoose.Location = new System.Drawing.Point(181, 37);
            this.labelChoose.Name = "labelChoose";
            this.labelChoose.Size = new System.Drawing.Size(149, 24);
            this.labelChoose.TabIndex = 9;
            this.labelChoose.Text = "CHOOSE ONE";
            // 
            // buttonCross
            // 
            this.buttonCross.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCross.Location = new System.Drawing.Point(543, 12);
            this.buttonCross.Name = "buttonCross";
            this.buttonCross.Size = new System.Drawing.Size(29, 24);
            this.buttonCross.TabIndex = 12;
            this.buttonCross.Text = "X";
            this.buttonCross.UseVisualStyleBackColor = true;
            this.buttonCross.Click += new System.EventHandler(this.buttonCross_Click);
            // 
            // AdminAccess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.buttonCross);
            this.Controls.Add(this.labelChoose);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.buttonMediInfo);
            this.Controls.Add(this.buttonCusInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminAccess";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminAccess";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCusInfo;
        private System.Windows.Forms.Button buttonMediInfo;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Label labelChoose;
        private System.Windows.Forms.Button buttonCross;
    }
}